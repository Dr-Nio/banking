<?php
	
	require_once('app/resource/inc/navbar.php');
	
	require_once('app/resource/inc/content.php');
	
	require_once('app/resource/inc/footer.php');

?>