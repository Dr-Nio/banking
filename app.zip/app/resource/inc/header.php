<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>CSC 215 BANK</title>

    <!-- Bootstrap core CSS -->
    <link href="app/resource/assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="app/resource/assets/css/sticky-footer.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <!--<link href="starter-template.css" rel="stylesheet">-->
  </head>
	<body>

    
		<?php require_once('app/resource/inc/body.php'); ?>
    
	
	</body>
</html>