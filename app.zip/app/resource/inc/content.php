	<main role="main" class="container">

      <div class="col-md-12">
        <!--<h1>CSC 215 BANK</h1>-->
        <br><br><br>
		<div class="col-md-12">
			
			<h1>Add New Account</h1>
			
			<form class="form-control form-control-sm">
				<div class="row">
					<div class="col-md-6">
					  <input type="text" class="form-control" placeholder="Names">
					</div>
					<div class="col-md-6">
					  <input type="text" class="form-control" placeholder="Email">
					</div>
				</div><br>
				
				<div class="row">
					<div class="col-md-12">
					  <input type="text" class="form-control" placeholder="Phone">
					</div>
					<div class="col-md-6"><br>
					  <button type="submit" class="btn btn-success">Enter</button>
					</div>
				</div>
			</form>
		</div>
		
		<div class="col-md-12">
			
		</div>
		
	  </div>

    </main><!-- /.container -->